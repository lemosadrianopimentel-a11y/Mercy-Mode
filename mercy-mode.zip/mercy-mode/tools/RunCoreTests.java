import javax.tools.*;
import java.nio.file.*;
import java.util.*;
import java.net.*;

/** Run with:  java tools/RunCoreTests.java   (JDK 17+; no Gradle, no network). */
public class RunCoreTests {
    public static void main(String[] args) throws Exception {
        Path out = Files.createTempDirectory("mercy-core");
        List<String> files = new ArrayList<>();
        for (String dir : new String[]{"src/core", "src/test"})
            try (var s = Files.walk(Path.of(dir))) { s.filter(p -> p.toString().endsWith(".java")).forEach(p -> files.add(p.toString())); }
        List<String> cmd = new ArrayList<>(List.of("-d", out.toString()));
        cmd.addAll(files);
        int rc = ToolProvider.getSystemJavaCompiler().run(null, null, null, cmd.toArray(new String[0]));
        if (rc != 0) System.exit(rc);
        try (URLClassLoader cl = new URLClassLoader(new URL[]{out.toUri().toURL()})) {
            cl.loadClass("mercymode.core.BattleTest").getMethod("main", String[].class).invoke(null, (Object) new String[0]);
        }
    }
}
