# Mercy Mode (working title)

An Undertale x Minecraft: Java Edition mashup. Right-click any mob with the **Determination Heart** to start an Undertale-style battle (FIGHT / ACT / MERCY plus a dodge phase) that can end in a spare or a kill. Single player.

> **Status: design only. Nothing here is built, tested or published yet.**

## How the two games are in it
| Game | Role | What it brings |
|---|---|---|
| Minecraft: Java Edition | `primary` (host) | The world and mobs. Fabric in a portable Prism Launcher instance. |
| Undertale | `companion` | Sprites, music, sound effects and fonts, read at runtime from the player's own install (`{game:undertale}`). |

**No Undertale files are in this repository or in any release.** Every player needs their own copy of both games.

## Features (v1 target)
- Determination Heart: right-click a mob to start a solo battle.
- Works on all mobs through templates (hostile, neutral, passive, aquatic) with per-mob overrides.
- Three boss fights, battle-only (they keep their Minecraft look in the world):
  - Wither = Photoshop Flowey
  - Ender Dragon = Sans (simplified, no Karma yet)
  - Warden = Undyne the Undying (simplified)
- Spare or kill outcomes, with rewards for sparing.

## Repository layout
- `design/`: JSON design sheets, the source of truth. Change a sheet before the code.
- `docs/AGENT_HANDOFF.md`: the full task list for a coding agent (Claude Code or Codex).
- `docs/recipe.draft.json`: unvalidated recipe sketch. Not `melty.json` on purpose.
- `src/core/`: the battle rules in plain Java, with passing tests (`java tools/RunCoreTests.java`).
- `src/mod/`: the Fabric mod layer. **Uncompiled and untested** against Minecraft; see the notes at the top of each file.
- `build.gradle`, `gradle.properties`: Fabric Loom setup with `TODO` versions to fill from fabricmc.net/develop.

## Open questions (to resolve before publishing)
- Can Undertale's sprites and audio be read at runtime from `data.win` inside a Fabric mod?
- Credits, content license and remix choice: **not decided yet**.

## License
Not chosen yet. Add a LICENSE file once decided. Undertale and Minecraft belong to their owners; this project is unofficial.
