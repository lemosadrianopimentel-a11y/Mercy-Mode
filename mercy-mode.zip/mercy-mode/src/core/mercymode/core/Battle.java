package mercymode.core;

import java.util.List;
import java.util.Map;

/** Pure battle rules (no Minecraft code). Driven by the rows in design/*.json. Single player. */
public final class Battle {
    public enum Phase { MENU, DODGE, ENDED }
    public enum Outcome { ONGOING, SPARED, KILLED }
    public record ActOption(String id, String label, int mercyDelta) {}

    private final int mercyNeeded;
    private final Map<String, ActOption> acts;
    private final List<String> actIds;
    private int mobHp;
    private int playerHp;
    private int mercy = 0;
    private Phase phase = Phase.MENU;
    private Outcome outcome = Outcome.ONGOING;

    public Battle(int mobHp, int playerHp, int mercyNeeded, List<ActOption> options) {
        if (mobHp <= 0 || playerHp <= 0) throw new IllegalArgumentException("hp must be > 0");
        this.mobHp = mobHp; this.playerHp = playerHp; this.mercyNeeded = mercyNeeded;
        this.acts = new java.util.LinkedHashMap<>();
        for (ActOption o : options) acts.put(o.id(), o);
        this.actIds = List.copyOf(acts.keySet());
    }

    public Phase phase() { return phase; }
    public Outcome outcome() { return outcome; }
    public int mobHp() { return mobHp; }
    public int playerHp() { return playerHp; }
    public int mercyPoints() { return mercy; }
    public List<String> actIds() { return actIds; }
    public boolean spareable() { return mercy >= mercyNeeded; }

    private void requireMenu() {
        if (phase != Phase.MENU) throw new IllegalStateException("not in MENU phase: " + phase);
    }

    /** FIGHT: damages the mob. Killing it ends the battle as KILLED. */
    public void fight(int damage) {
        requireMenu();
        mobHp = Math.max(0, mobHp - Math.max(0, damage));
        if (mobHp == 0) { phase = Phase.ENDED; outcome = Outcome.KILLED; }
        else phase = Phase.DODGE;
    }

    /** ACT: changes mercy by the option's delta (clamped 0..100). */
    public void act(String optionId) {
        requireMenu();
        ActOption o = acts.get(optionId);
        if (o == null) throw new IllegalArgumentException("unknown ACT option: " + optionId);
        mercy = Math.max(0, Math.min(100, mercy + o.mercyDelta()));
        phase = Phase.DODGE;
    }

    /** MERCY: spares the mob if the condition is met; otherwise the mob keeps attacking. */
    public boolean mercy() {
        requireMenu();
        if (spareable()) { phase = Phase.ENDED; outcome = Outcome.SPARED; return true; }
        phase = Phase.DODGE;
        return false;
    }

    /** End of the dodge phase: the player took this much damage. Dying ends the battle; the mob survives. */
    public void endDodge(int damageTaken) {
        if (phase != Phase.DODGE) throw new IllegalStateException("not in DODGE phase: " + phase);
        playerHp = Math.max(0, playerHp - Math.max(0, damageTaken));
        phase = playerHp == 0 ? Phase.ENDED : Phase.MENU;
    }
}
