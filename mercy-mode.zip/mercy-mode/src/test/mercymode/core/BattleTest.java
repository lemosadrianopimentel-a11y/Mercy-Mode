package mercymode.core;

import java.util.List;
import mercymode.core.Battle.*;

public class BattleTest {
    static int failures = 0;
    static void check(boolean ok, String name) {
        System.out.println((ok ? "PASS " : "FAIL ") + name);
        if (!ok) failures++;
    }
    static Battle fresh() {
        return new Battle(20, 20, 100, List.of(new ActOption("check", "Check", 0),
            new ActOption("talk", "Talk", 50), new ActOption("threaten", "Threaten", -20)));
    }
    public static void main(String[] a) {
        Battle b = fresh();
        b.act("talk"); b.endDodge(3); b.act("talk"); b.endDodge(0);
        check(b.mercyPoints() == 100 && b.spareable(), "ACT twice reaches spare");
        check(b.mercy() && b.outcome() == Outcome.SPARED && b.phase() == Phase.ENDED, "MERCY spares when ready");

        b = fresh(); b.act("talk"); b.endDodge(0);
        check(!b.mercy() && b.outcome() == Outcome.ONGOING && b.phase() == Phase.DODGE, "MERCY fails below threshold");

        b = fresh(); b.fight(20);
        check(b.outcome() == Outcome.KILLED && b.phase() == Phase.ENDED, "FIGHT kills at 0 HP");

        b = fresh(); b.fight(5); b.endDodge(0);
        check(b.mobHp() == 15 && b.phase() == Phase.MENU, "FIGHT hurts, then back to MENU");

        b = fresh(); b.act("threaten");
        check(b.mercyPoints() == 0, "mercy clamps at 0");

        b = fresh(); b.act("check"); b.endDodge(25);
        check(b.playerHp() == 0 && b.phase() == Phase.ENDED && b.outcome() == Outcome.ONGOING, "player death ends battle, mob survives");

        boolean threw = false;
        try { fresh().endDodge(1); } catch (IllegalStateException e) { threw = true; }
        check(threw, "cannot dodge during MENU");
        threw = false;
        try { fresh().act("nope"); } catch (IllegalArgumentException e) { threw = true; }
        check(threw, "unknown ACT option rejected");

        System.out.println(failures == 0 ? "ALL PASSED" : failures + " FAILED");
        System.exit(failures == 0 ? 0 : 1);
    }
}
