package mercymode;

import com.mojang.brigadier.arguments.StringArgumentType;
import java.util.*;
import mercymode.core.Battle;
import mercymode.core.Battle.ActOption;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;

/**
 * UNCOMPILED AND UNTESTED against Minecraft. Written for a Fabric 1.21.x / Yarn setup;
 * registry and Item.Settings calls changed between versions, so adjust to the chosen version.
 * The battle rules live in mercymode.core.Battle (tested separately).
 *
 * Temporary text controls so the loop can be tested before a real UI exists:
 *   /mercy fight | /mercy act <id> | /mercy spare | /mercy dodge
 */
public class MercyMode implements ModInitializer {
    public static final String ID = "mercymode";
    public static Item HEART;
    private static final Map<UUID, Battle> BATTLES = new HashMap<>();

    @Override
    public void onInitialize() {
        // TODO(version): 1.21.2+ needs the registry key set on Item.Settings.
        HEART = Registry.register(Registries.ITEM, Identifier.of(ID, "determination_heart"),
                new Item(new Item.Settings().maxCount(1)));

        UseEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClient() || !player.getStackInHand(hand).isOf(HEART)) return ActionResult.PASS;
            if (!(entity instanceof LivingEntity mob) || !(player instanceof ServerPlayerEntity sp)) return ActionResult.PASS;
            if (BATTLES.containsKey(sp.getUuid())) { say(sp, "You are already in a battle."); return ActionResult.SUCCESS; }
            // TODO: read HP, ACT options and spare threshold from design/templates.json + mobs.json.
            BATTLES.put(sp.getUuid(), new Battle(Math.round(mob.getMaxHealth()), 20, 100, List.of(
                    new ActOption("check", "Check", 0), new ActOption("talk", "Talk", 50), new ActOption("compliment", "Compliment", 50))));
            say(sp, "A battle begins! Use /mercy fight, /mercy act <check|talk|compliment>, /mercy spare.");
            // TODO: freeze the mob's AI while the battle lasts; open the battle screen.
            return ActionResult.SUCCESS;
        });

        CommandRegistrationCallback.EVENT.register((dispatcher, registry, env) -> dispatcher.register(
            CommandManager.literal("mercy")
                .then(CommandManager.literal("fight").executes(c -> run(c.getSource().getPlayer(), "fight", null)))
                .then(CommandManager.literal("spare").executes(c -> run(c.getSource().getPlayer(), "spare", null)))
                .then(CommandManager.literal("dodge").executes(c -> run(c.getSource().getPlayer(), "dodge", null)))
                .then(CommandManager.literal("act").then(CommandManager.argument("id", StringArgumentType.word())
                    .executes(c -> run(c.getSource().getPlayer(), "act", StringArgumentType.getString(c, "id")))))));
    }

    private static int run(ServerPlayerEntity p, String action, String arg) {
        Battle b = p == null ? null : BATTLES.get(p.getUuid());
        if (b == null) { if (p != null) say(p, "You are not in a battle."); return 0; }
        try {
            switch (action) {
                case "fight" -> b.fight(5);
                case "act" -> b.act(arg);
                case "spare" -> say(p, b.mercy() ? "You spared it." : "It is not ready to be spared.");
                case "dodge" -> b.endDodge(0); // TODO: replace with a real dodge phase
            }
        } catch (RuntimeException e) { say(p, e.getMessage()); return 0; }
        say(p, "Mob HP " + b.mobHp() + " | Your HP " + b.playerHp() + " | Mercy " + b.mercyPoints() + " | " + b.phase());
        if (b.phase() == Battle.Phase.ENDED) { BATTLES.remove(p.getUuid()); say(p, "Battle over: " + b.outcome()); }
        return 1;
    }

    private static void say(ServerPlayerEntity p, String msg) { p.sendMessage(Text.literal(msg), false); }
}
