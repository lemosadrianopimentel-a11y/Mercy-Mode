package mercymode;

import java.nio.file.*;
import java.util.Optional;

/**
 * Finds the player's own Undertale folder. Melty gives it to the mod through the recipe
 * ("{game:undertale}" mapped to the env var MERCYMODE_UNDERTALE_DIR). Nothing is copied or shipped.
 * NOT DONE: reading sprites/audio out of data.win (a GameMaker archive). Verify this is possible first.
 */
public final class UndertaleFiles {
    public static final String ENV = "MERCYMODE_UNDERTALE_DIR";
    private UndertaleFiles() {}

    public static Optional<Path> folder() {
        String v = System.getenv(ENV);
        if (v == null || v.isBlank()) return Optional.empty();
        Path p = Path.of(v);
        return Files.exists(p.resolve("data.win")) ? Optional.of(p) : Optional.empty();
    }
}
