# Handoff for a coding agent (Claude Code / Codex)

Use together with the Melty Publish prompt (never commit the token).

## Decisions from the owner
- SINGLE PLAYER ONLY. No co-op, no call-out window, no multiplayer code. Do NOT add recipe.multiplayer. Make sure the README and the Melty description say it is single player, with no "co-op" or "friends" wording.
- Update the existing draft with update_mod (modId is in the Melty prompt).
- Mode "installed": Fabric via a portable Prism instance (mmc-pack.json naming Fabric, mod in mods/). Undertale is companion via {game:undertale}; no Undertale files in the upload.

## Tasks
1. Confirm Undertale sprites/audio can be read at runtime from data.win inside a Fabric mod. If not, stop and tell me.
2. Set up universal-modder (skills/mod-any-game/SKILL.md). Ask before spending money.
3. Fill design/*.json, run the preflight, then build: item, interaction hook, mob freeze, battle UI, solo loop, templates, three bosses (battle-only, simplified).
4. Build the Fabric mod and the Prism instance; test in the running game.
5. inspect_package, validate_recipe, one_click_check (says = README feature list). Fix every finding.
6. Upload to the draft, real screenshot of a battle, ask before publish.
7. report_fix_attempt: "fixed" only if the submitted release passes one_click_check.

## State of the source (be honest in the listing)
- src/core/Battle.java: tested (9 passing checks via `java tools/RunCoreTests.java`).
- src/mod/: NEVER COMPILED. Pick the Minecraft/Fabric versions first (look them up, do not guess), fill gradle.properties, then fix compile errors. API calls are written for 1.21.x Yarn and may need changes.
- Works as text commands (/mercy ...) so the loop can be tested before a UI exists. Still missing: sheet loading, mob freeze, battle screen, dodge phase, bosses, Undertale asset reading (UndertaleFiles only finds the folder; reading data.win is not written and may not be possible).
- The recipe must pass the Undertale folder to the mod as the env var MERCYMODE_UNDERTALE_DIR ("{game:undertale}").
